package com.yomyom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutentificacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
