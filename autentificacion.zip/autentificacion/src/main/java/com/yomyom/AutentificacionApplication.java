package com.yomyom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutentificacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutentificacionApplication.class, args);
	}

}
